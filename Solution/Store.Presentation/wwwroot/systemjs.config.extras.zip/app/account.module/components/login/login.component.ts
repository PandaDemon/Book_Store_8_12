﻿import { Component } from '@angular/core';

@Component({
    selector: 'my-login',
    templateUrl: '/partial/loginComponent'
})

export class IndexComponent {
}
