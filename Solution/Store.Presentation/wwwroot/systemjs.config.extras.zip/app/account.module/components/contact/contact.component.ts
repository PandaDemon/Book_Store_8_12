﻿import { Component } from '@angular/core';

@Component({
    selector: 'my-contact',
    templateUrl: '/partial/contactComponent'
})

export class ContactComponent {
}