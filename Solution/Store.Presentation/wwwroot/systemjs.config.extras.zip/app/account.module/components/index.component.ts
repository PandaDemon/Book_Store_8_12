﻿import { Component } from '@angular/core';

@Component({
    selector: 'index',
    templateUrl: '/partial/indexComponent'
})

export class IndexComponent {
}