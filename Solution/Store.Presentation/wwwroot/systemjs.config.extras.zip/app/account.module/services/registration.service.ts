﻿import { Injectable } from '@angular/core';
//import { FormGroup } from '@angular/forms';
//import { HttpClient } from "@angular/common/http";

//@Injectable({
//    providedIn: 'root'
//})
export class RegistrationService {

constructor() { }
//    readonly BaseURi = "http://localhost:56189";

//    comparePasswords(fb: FormGroup) {
//        let confirmPaswCtrl = fb.get('PasswordConfirm');
//        if (confirmPaswCtrl.errors == null || 'passwordMismatch' in confirmPaswCtrl.errors) {
//            if (fb.get('Password').value != confirmPaswCtrl.value) {
//                confirmPaswCtrl.setErrors({ passwordMismatch: true });
//            } else {
//                confirmPaswCtrl.setErrors(null);
//            }
//        }
//    }

//    register() {
//        var body = {
//            Email: this.value.Email,
//            Password: this.value.Passwords.Password,
//            PasswordConfirm: this.value.Passwords.PasswordConfirm
//        };
//        return this.http.post(this.BaseURi + '/account/register', body);
//    }

}