"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//import { FormGroup } from '@angular/forms';
//import { HttpClient } from "@angular/common/http";
//@Injectable({
//    providedIn: 'root'
//})
var RegistrationService = (function () {
    function RegistrationService() {
    }
    return RegistrationService;
}());
exports.RegistrationService = RegistrationService;
//# sourceMappingURL=registration.service.js.map